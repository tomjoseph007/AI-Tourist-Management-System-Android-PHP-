<?php
$con=mysqli_connect("localhost","root","","smart_travel") or die("error");
?>